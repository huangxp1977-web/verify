<?php
// 提高内存限制和执行时间
ini_set('memory_limit', '256M');
ini_set('max_execution_time', 300);

session_start();
require __DIR__ . '/../config/config.php';

// 检查登录状态
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 获取当前层级和ID
$level = isset($_GET['level']) ? $_GET['level'] : 'box';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 获取筛选参数
$batch_number = isset($_GET['batch_number']) ? trim($_GET['batch_number']) : '';
$production_date = isset($_GET['production_date']) ? trim($_GET['production_date']) : '';
$selected_backup_date = isset($_POST['backup_date']) ? trim($_POST['backup_date']) : '';

// 导航路径
$breadcrumb = [];
$data = [];
$title = '';
$parent_id = 0;
$parent_data = [];
$backup_dates = [];

// 存储计数缓存，避免重复查询
$box_carton_counts = [];  // 箱子ID => 盒子数量
$carton_product_counts = [];  // 盒子ID => 产品数量

try {
    // 获取备份日期
    $stmt = $pdo->query("
        SELECT DISTINCT DATE(deleted_at) AS backup_date 
        FROM (
            SELECT deleted_at FROM boxes_backup
            UNION ALL
            SELECT deleted_at FROM cartons_backup
            UNION ALL
            SELECT deleted_at FROM products_backup
        ) AS all_backups
        ORDER BY backup_date DESC
    ");
    $backup_dates = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $error = "获取备份日期失败: " . $e->getMessage();
}


// 清空（删除）前自动备份
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['clear'])) {
    try {
        $pdo->beginTransaction();

        if ($level == 'box') {
            // 备份产品
            $pdo->exec("
                INSERT INTO products_backup 
                (original_id, product_code, carton_id, product_name, region, image_url, batch_number, production_date, distributor_id)
                SELECT id, product_code, carton_id, product_name, region, image_url, batch_number, production_date, distributor_id
                FROM products
            ");

            // 备份盒子
            $pdo->exec("
                INSERT INTO cartons_backup 
                (original_id, carton_code, box_id, batch_number, production_date, distributor_id)
                SELECT id, carton_code, box_id, batch_number, production_date, distributor_id
                FROM cartons
            ");

            // 备份箱子
            $pdo->exec("
                INSERT INTO boxes_backup 
                (original_id, box_code, batch_number, production_date, distributor_id)
                SELECT id, box_code, batch_number, production_date, distributor_id
                FROM boxes
            ");

            // 分批次删除
            batchDelete($pdo, 'products', 1000);
            batchDelete($pdo, 'cartons', 1000);
            batchDelete($pdo, 'boxes', 1000);
            
            $success = "所有箱子、盒子、产品已备份并清空（备份日期：" . date('Y-m-d') . "）";

        } elseif ($level == 'carton' && $id > 0) {
            // 备份当前箱子下的产品
            $stmt = $pdo->prepare("
                INSERT INTO products_backup 
                SELECT p.id, p.product_code, p.carton_id, p.product_name, p.region, p.image_url, p.batch_number, p.production_date, p.distributor_id, NOW()
                FROM products p
                JOIN cartons c ON p.carton_id = c.id
                WHERE c.box_id = :bid
            ");
            $stmt->bindParam(':bid', $id);
            $stmt->execute();

            // 备份当前箱子下的盒子
            $stmt = $pdo->prepare("
                INSERT INTO cartons_backup 
                SELECT id, carton_code, box_id, batch_number, production_date, distributor_id, NOW()
                FROM cartons
                WHERE box_id = :bid
            ");
            $stmt->bindParam(':bid', $id);
            $stmt->execute();

            // 分批次删除
            $stmt = $pdo->prepare("SELECT id FROM cartons WHERE box_id = :bid");
            $stmt->bindParam(':bid', $id);
            $stmt->execute();
            $cartonIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($cartonIds as $cartonId) {
                batchDelete($pdo, 'products', 1000, "carton_id = $cartonId");
            }
            batchDelete($pdo, 'cartons', 1000, "box_id = $id");
            
            $success = "箱子【ID:$id】下的盒子、产品已备份并清空（备份日期：" . date('Y-m-d') . "）";

        } elseif ($level == 'product' && $id > 0) {
            // 备份当前盒子下的产品
            $stmt = $pdo->prepare("
                INSERT INTO products_backup 
                SELECT id, product_code, carton_id, product_name, region, image_url, batch_number, production_date, distributor_id, NOW()
                FROM products
                WHERE carton_id = :cid
            ");
            $stmt->bindParam(':cid', $id);
            $stmt->execute();

            // 分批次删除
            batchDelete($pdo, 'products', 1000, "carton_id = $id");
            
            $success = "盒子【ID:$id】下的产品已备份并清空（备份日期：" . date('Y-m-d') . "）";
        }

        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "清空/备份失败: " . $e->getMessage();
    }
}


// 恢复备份
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['restore']) && !empty($selected_backup_date)) {
    try {
        $pdo->beginTransaction();
        
        $box_id_map = [];
        $carton_id_map = [];

        // 恢复箱子
        $stmt = $pdo->prepare("SELECT * FROM boxes_backup WHERE DATE(deleted_at) = :date");
        $stmt->bindParam(':date', $selected_backup_date);
        $stmt->execute();
        $boxes_backup = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($boxes_backup as $b) {
            $check = $pdo->prepare("SELECT id FROM boxes WHERE box_code = :code");
            $check->bindParam(':code', $b['box_code']);
            $check->execute();
            $existing = $check->fetch();
            
            if ($existing) {
                $box_id_map[$b['original_id']] = $existing['id'];
            } else {
                $pdo->prepare("
                    INSERT INTO boxes 
                    (box_code, batch_number, production_date, distributor_id)
                    VALUES (:code, :batch, :date, :did)
                ")->execute([
                    ':code' => $b['box_code'],
                    ':batch' => $b['batch_number'],
                    ':date' => $b['production_date'],
                    ':did' => $b['distributor_id']
                ]);
                $new_id = $pdo->lastInsertId();
                $box_id_map[$b['original_id']] = $new_id;
            }
        }

        // 恢复盒子
        $stmt = $pdo->prepare("SELECT * FROM cartons_backup WHERE DATE(deleted_at) = :date");
        $stmt->bindParam(':date', $selected_backup_date);
        $stmt->execute();
        $cartons_backup = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($cartons_backup as $c) {
            if (!isset($box_id_map[$c['box_id']])) {
                throw new Exception("恢复失败：找不到箱子ID为 {$c['box_id']} 的对应记录");
            }
            
            $mapped_box_id = $box_id_map[$c['box_id']];
            $check = $pdo->prepare("SELECT id FROM cartons WHERE carton_code = :code");
            $check->bindParam(':code', $c['carton_code']);
            $check->execute();
            $existing = $check->fetch();
            
            if ($existing) {
                $carton_id_map[$c['original_id']] = $existing['id'];
            } else {
                $pdo->prepare("
                    INSERT INTO cartons 
                    (carton_code, box_id, batch_number, production_date, distributor_id)
                    VALUES (:code, :bid, :batch, :date, :did)
                ")->execute([
                    ':code' => $c['carton_code'],
                    ':bid' => $mapped_box_id,
                    ':batch' => $c['batch_number'],
                    ':date' => $c['production_date'],
                    ':did' => $c['distributor_id']
                ]);
                $new_id = $pdo->lastInsertId();
                $carton_id_map[$c['original_id']] = $new_id;
            }
        }

        // 恢复产品
        $stmt = $pdo->prepare("SELECT * FROM products_backup WHERE DATE(deleted_at) = :date");
        $stmt->bindParam(':date', $selected_backup_date);
        $stmt->execute();
        $products_backup = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($products_backup as $p) {
            if (!isset($carton_id_map[$p['carton_id']])) {
                throw new Exception("恢复失败：找不到盒子ID为 {$p['carton_id']} 的对应记录");
            }
            
            $mapped_carton_id = $carton_id_map[$p['carton_id']];
            $check = $pdo->prepare("SELECT id FROM products WHERE product_code = :code");
            $check->bindParam(':code', $p['product_code']);
            $check->execute();
            if (!$check->fetch()) {
                $pdo->prepare("
                    INSERT INTO products 
                    (product_code, carton_id, product_name, region, image_url, batch_number, production_date, distributor_id)
                    VALUES (:code, :cid, :name, :region, :img, :batch, :date, :did)
                ")->execute([
                    ':code' => $p['product_code'],
                    ':cid' => $mapped_carton_id,
                    ':name' => $p['product_name'],
                    ':region' => $p['region'],
                    ':img' => $p['image_url'],
                    ':batch' => $p['batch_number'],
                    ':date' => $p['production_date'],
                    ':did' => $p['distributor_id']
                ]);
            }
        }

        $pdo->commit();
        $success = "已成功恢复【" . $selected_backup_date . "】的备份数据";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "恢复失败: " . $e->getMessage();
    }
}


// 处理导出请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['export'])) {
    $export_format = isset($_POST['format']) ? $_POST['format'] : 'txt';
    $export_data = [];
    $export_title = '';
    $queryUrl = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/index.php?code=";
    
    try {
        if ($level == 'box') {
            $stmt = $pdo->prepare("
                SELECT box_code, batch_number, DATE(production_date) as production_date 
                FROM boxes 
                ORDER BY production_date DESC, box_code ASC
            ");
            $stmt->execute();
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($items as $item) {
                $export_data[] = [
                    'code' => $item['box_code'],
                    'batch' => $item['batch_number'],
                    'date' => $item['production_date'],
                    'url' => $queryUrl . urlencode($item['box_code'])
                ];
            }
            $export_title = '箱子';
        } elseif ($level == 'carton') {
            $stmt = $pdo->prepare("
                SELECT carton_code, batch_number, DATE(production_date) as production_date 
                FROM cartons 
                WHERE box_id = :box_id
                ORDER BY carton_code ASC
            ");
            $stmt->bindParam(':box_id', $id);
            $stmt->execute();
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($items as $item) {
                $export_data[] = [
                    'code' => $item['carton_code'],
                    'batch' => $item['batch_number'],
                    'date' => $item['production_date'],
                    'url' => $queryUrl . urlencode($item['carton_code'])
                ];
            }
            $export_title = '盒子';
        } elseif ($level == 'product') {
            $stmt = $pdo->prepare("
                SELECT product_code, batch_number, DATE(production_date) as production_date, product_name, region
                FROM products 
                WHERE carton_id = :carton_id
                ORDER BY product_code ASC
            ");
            $stmt->bindParam(':carton_id', $id);
            $stmt->execute();
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($items as $item) {
                $export_data[] = [
                    'code' => $item['product_code'],
                    'batch' => $item['batch_number'],
                    'date' => $item['production_date'],
                    'name' => $item['product_name'],
                    'region' => $item['region'],
                    'url' => $queryUrl . urlencode($item['product_code'])
                ];
            }
            $export_title = '产品';
        }
        
        if (empty($export_data)) {
            $error = "没有可导出的数据";
        } else {
            if ($export_format == 'txt') {
                exportAsTxt($export_data, $export_title, $level);
            } else {
                exportAsExcel($export_data, $export_title, $level);
            }
        }
    } catch(PDOException $e) {
        $error = "导出数据出错: " . $e->getMessage();
    }
}

// 处理编辑请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit'])) {
    $item_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $success = '';
    
    try {
        if ($level == 'box') {
            $stmt = $pdo->prepare("
                UPDATE boxes 
                SET batch_number = :batch, production_date = :date 
                WHERE id = :id
            ");
            $stmt->bindParam(':batch', $_POST['batch_number']);
            $stmt->bindParam(':date', $_POST['production_date']);
            $stmt->bindParam(':id', $item_id);
            $stmt->execute();
            $success = "箱子信息更新成功";
        } elseif ($level == 'carton') {
            $stmt = $pdo->prepare("
                UPDATE cartons 
                SET batch_number = :batch, production_date = :date 
                WHERE id = :id
            ");
            $stmt->bindParam(':batch', $_POST['batch_number']);
            $stmt->bindParam(':date', $_POST['production_date']);
            $stmt->bindParam(':id', $item_id);
            $stmt->execute();
            $success = "盒子信息更新成功";
        } elseif ($level == 'product') {
            $stmt = $pdo->prepare("
                UPDATE products 
                SET product_name = :name, region = :region, image_url = :image,
                    batch_number = :batch, production_date = :date 
                WHERE id = :id
            ");
            $stmt->bindParam(':name', $_POST['product_name']);
            $stmt->bindParam(':region', $_POST['region']);
            $stmt->bindParam(':image', $_POST['image_url']);
            $stmt->bindParam(':batch', $_POST['batch_number']);
            $stmt->bindParam(':date', $_POST['production_date']);
            $stmt->bindParam(':id', $item_id);
            $stmt->execute();
            $success = "产品信息更新成功";
        }
    } catch(PDOException $e) {
        $error = "更新信息出错: " . $e->getMessage();
    }
}

// 性能优化：添加分页功能
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$page_size = 50;
$offset = ($page - 1) * $page_size;
$total_records = 0;

// 获取数据和数量统计
try {
    if ($level == 'box') {
        $title = '箱子列表';
        $breadcrumb[] = ['name' => '箱子列表', 'url' => 'admin_list.php?level=box'];
        
        // 构建查询条件
        $where_clause = '';
        $params = [];
        
        if (!empty($batch_number)) {
            $where_clause .= " WHERE batch_number = :batch_number";
            $params[':batch_number'] = $batch_number;
        }
        
        if (!empty($production_date)) {
            $where_clause .= (empty($where_clause) ? " WHERE" : " AND") . " DATE(production_date) = :production_date";
            $params[':production_date'] = $production_date;
        }
        
        // 获取总记录数
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM boxes" . $where_clause);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $total_records = $stmt->fetchColumn();
        
        // 获取箱子数据
        $stmt = $pdo->prepare("        
            SELECT boxes.*, distributors.name as distributor_name 
            FROM boxes 
            LEFT JOIN distributors ON boxes.distributor_id = distributors.id" . $where_clause . "
            ORDER BY production_date DESC, box_code ASC
            LIMIT :offset, :page_size
        ");
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindParam(':page_size', $page_size, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 批量获取每个箱子的盒子数量（优化查询性能）
        if (!empty($data)) {
            $boxIds = array_column($data, 'id');
            $placeholders = implode(',', array_fill(0, count($boxIds), '?'));
            
            $stmt = $pdo->prepare("
                SELECT box_id, COUNT(*) as count 
                FROM cartons 
                WHERE box_id IN ($placeholders) 
                GROUP BY box_id
            ");
            $stmt->execute($boxIds);
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $box_carton_counts[$row['box_id']] = $row['count'];
            }
        }
        
    } elseif ($level == 'carton' && $id > 0) {
        $title = '盒子列表';
        
        // 获取箱子信息
        $stmt = $pdo->prepare("SELECT * FROM boxes WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $parent_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$parent_data) {
            throw new Exception("未找到指定的箱子");
        }
        
        $breadcrumb[] = ['name' => '箱子列表', 'url' => 'admin_list.php?level=box'];
        $breadcrumb[] = [
            'name' => "箱子: {$parent_data['box_code']}", 
            'url' => "admin_list.php?level=carton&id={$id}"
        ];
        
        // 获取总记录数
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM cartons WHERE box_id = :box_id");
        $stmt->bindParam(':box_id', $id);
        $stmt->execute();
        $total_records = $stmt->fetchColumn();
        
        // 获取盒子数据
        $stmt = $pdo->prepare("            
            SELECT cartons.*, distributors.name as distributor_name 
            FROM cartons 
            LEFT JOIN distributors ON cartons.distributor_id = distributors.id
            WHERE box_id = :box_id
            ORDER BY carton_code ASC
            LIMIT :offset, :page_size
        ");
        $stmt->bindParam(':box_id', $id);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindParam(':page_size', $page_size, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $parent_id = $id;
        
        // 批量获取每个盒子的产品数量
        if (!empty($data)) {
            $cartonIds = array_column($data, 'id');
            $placeholders = implode(',', array_fill(0, count($cartonIds), '?'));
            
            $stmt = $pdo->prepare("
                SELECT carton_id, COUNT(*) as count 
                FROM products 
                WHERE carton_id IN ($placeholders) 
                GROUP BY carton_id
            ");
            $stmt->execute($cartonIds);
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $carton_product_counts[$row['carton_id']] = $row['count'];
            }
        }
        
    } elseif ($level == 'product' && $id > 0) {
        $title = '产品列表';
        
        // 获取盒子信息
        $stmt = $pdo->prepare("SELECT * FROM cartons WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $carton_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$carton_data) {
            throw new Exception("未找到指定的盒子");
        }
        
        // 获取所属箱子信息
        $stmt = $pdo->prepare("SELECT * FROM boxes WHERE id = :id");
        $stmt->bindParam(':id', $carton_data['box_id']);
        $stmt->execute();
        $box_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $breadcrumb[] = ['name' => '箱子列表', 'url' => 'admin_list.php?level=box'];
        $breadcrumb[] = [
            'name' => "箱子: {$box_data['box_code']}", 
            'url' => "admin_list.php?level=carton&id={$box_data['id']}"
        ];
        $breadcrumb[] = [
            'name' => "盒子: {$carton_data['carton_code']}", 
            'url' => "admin_list.php?level=product&id={$id}"
        ];
        
        // 获取总记录数
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE carton_id = :carton_id");
        $stmt->bindParam(':carton_id', $id);
        $stmt->execute();
        $total_records = $stmt->fetchColumn();
        
        // 获取产品数据
        $stmt = $pdo->prepare("            
            SELECT products.*, distributors.name as distributor_name 
            FROM products 
            LEFT JOIN distributors ON products.distributor_id = distributors.id
            WHERE carton_id = :carton_id
            ORDER BY product_code ASC
            LIMIT :offset, :page_size
        ");
        $stmt->bindParam(':carton_id', $id);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindParam(':page_size', $page_size, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $parent_id = $id;
    } else {
        throw new Exception("无效的请求参数");
    }
    
    // 计算总页数
    $total_pages = ceil($total_records / $page_size);
} catch(Exception $e) {
    $error = $e->getMessage();
}

// 生成分页链接的函数
function generate_pagination($current_page, $total_pages, $base_url) {
    $pagination = '<div class="pagination">';
    $pagination .= '<span>共 ' . $total_pages . ' 页，第 ' . $current_page . ' 页</span>';
    
    if ($current_page > 1) {
        $pagination .= '<a href="' . $base_url . '&page=' . ($current_page - 1) . '">上一页</a>';
    }
    
    $start = max(1, $current_page - 2);
    $end = min($total_pages, $current_page + 2);
    
    if ($start > 1) {
        $pagination .= '<a href="' . $base_url . '&page=1">1</a>';
        if ($start > 2) {
            $pagination .= '<span>...</span>';
        }
    }
    
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $current_page) {
            $pagination .= '<span class="current">' . $i . '</span>';
        } else {
            $pagination .= '<a href="' . $base_url . '&page=' . $i . '">' . $i . '</a>';
        }
    }
    
    if ($end < $total_pages) {
        if ($end < $total_pages - 1) {
            $pagination .= '<span>...</span>';
        }
        $pagination .= '<a href="' . $base_url . '&page=' . $total_pages . '">' . $total_pages . '</a>';
    }
    
    if ($current_page < $total_pages) {
        $pagination .= '<a href="' . $base_url . '&page=' . ($current_page + 1) . '">下一页</a>';
    }
    
    $pagination .= '</div>';
    return $pagination;
}

// 导出为TXT文件
function exportAsTxt($data, $title, $level) {
    $filename = $title . '防伪码_' . date('YmdHis') . '.txt';
    
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    if ($level == 'product') {
        echo "防伪码\t产品名称\t生产地区\t批号\t生产日期\t查询网址\n";
    } else {
        echo "防伪码\t批号\t生产日期\t查询网址\n";
    }
    
    foreach ($data as $item) {
        if ($level == 'product') {
            echo $item['code'] . "\t" .
                 $item['name'] . "\t" .
                 $item['region'] . "\t" .
                 $item['batch'] . "\t" .
                 $item['date'] . "\t" .
                 $item['url'] . "\n";
        } else {
            echo $item['code'] . "\t" .
                 $item['batch'] . "\t" .
                 $item['date'] . "\t" .
                 $item['url'] . "\n";
        }
    }
    exit;
}

// 导出为Excel文件（CSV格式）
function exportAsExcel($data, $title, $level) {
    $filename = $title . '防伪码_' . date('YmdHis') . '.csv';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $fp = fopen('php://output', 'w');
    fwrite($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));
    
    if ($level == 'product') {
        fputcsv($fp, ['防伪码', '产品名称', '生产地区', '批号', '生产日期', '查询网址']);
    } else {
        fputcsv($fp, ['防伪码', '批号', '生产日期', '查询网址']);
    }
    
    foreach ($data as $item) {
        if ($level == 'product') {
            fputcsv($fp, [
                $item['code'],
                $item['name'],
                $item['region'],
                $item['batch'],
                $item['date'],
                $item['url']
            ]);
        } else {
            fputcsv($fp, [
                $item['code'],
                $item['batch'],
                $item['date'],
                $item['url']
            ]);
        }
    }
    
    fclose($fp);
    exit;
}

// 分批次删除数据的函数
function batchDelete($pdo, $table, $batchSize = 1000, $whereClause = '') {
    $where = $whereClause ? "WHERE $whereClause" : '';
    
    do {
        $stmt = $pdo->query("DELETE FROM $table $where LIMIT $batchSize");
        $deletedRows = $stmt->rowCount();
        unset($stmt);
    } while ($deletedRows >= $batchSize);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> - 产品溯源管理系统</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #333;
        }
        .header {
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
        .breadcrumb {
            margin: 0 0 20px 0;
            padding: 0;
            list-style: none;
        }
        .breadcrumb li {
            display: inline-block;
        }
        .breadcrumb li::after {
            content: ">";
            margin: 0 10px;
            color: #999;
        }
        .breadcrumb li:last-child::after {
            content: "";
        }
        .breadcrumb a {
            color: #3498db;
            text-decoration: none;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .export-form {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background-color: #f9f9f9;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            padding: 6px 12px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn:hover {
            background: #45a049;
        }
        .btn-secondary {
            background: #3498db;
        }
        .btn-secondary:hover {
            background: #2980b9;
        }
        .btn-edit {
            background: #f39c12;
        }
        .btn-edit:hover {
            background: #e67e22;
        }
        .btn-back {
            background: #95a5a6;
            margin-bottom: 20px;
            display: inline-block;
        }
        .btn-back:hover {
            background: #7f8c8d;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
            max-width: 600px;
            position: relative;
        }
        .close {
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .success {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .error {
            background-color: #f2dede;
            color: #a94442;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .actions {
            display: flex;
            gap: 5px;
        }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            padding: 8px 12px;
            text-decoration: none;
            border: 1px solid #ddd;
            border-radius: 4px;
            color: #333;
        }
        .pagination a:hover {
            background-color: #f5f5f5;
            border-color: #8c6f3f;
            color: #8c6f3f;
        }
        .pagination span.current {
            background-color: #8c6f3f;
            color: white;
            border-color: #8c6f3f;
        }
        .pagination span {
            color: #999;
        }
        .sidebar {
            width: 220px;
            background-color: #8c6f3f;
            color: white;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid #a68c52;
            margin-bottom: 20px;
        }
        .sidebar-header h2 {
            color: white;
            font-size: 18px;
            margin: 0;
            text-align: center;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-menu li {
            margin: 0;
        }
        .sidebar-menu a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .sidebar-menu a:hover {
            background-color: #6d5732;
        }
        .sidebar-menu a.active {
            background-color: #6d5732;
            border-left: 4px solid #fff;
        }
        .main-content {
            flex: 1;
            margin-left: 220px;
            padding: 20px;
        }
        .container {
            margin-top: 0 !important;
        }
        
        .restore-form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }
        .restore-form select {
            width: auto;
            padding: 6px;
        }
        .btn-danger {
            background: #e74c3c;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .btn-restore {
            background: #2ecc71;
        }
        .btn-restore:hover {
            background: #27ae60;
        }
    </style>
</head>
<body>
    <!-- 左侧导航栏 -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>产品溯源系统</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin.php">系统首页</a></li>
            <li><a href="admin_list.php" class="active">产品列表</a></li>
            <li><a href="admin_distributors.php">经销商管理</a></li>
            <li><a href="admin_warehouse_staff.php">出库人员管理</a></li>
            <li><a href="admin_certificates.php" target="_blank">证书管理</a></li>
            <li><a href="admin.php?action=logout">退出登录</a></li>
        </ul>
    </div>
    
    <!-- 主内容区域 -->
    <div class="main-content">
        <div class="container">
            <div class="header">
                <h1>产品列表</h1>
            </div>
        
        <!-- 面包屑导航 -->
        <ul class="breadcrumb">
            <?php foreach ($breadcrumb as $item): ?>
                <li><a href="<?php echo $item['url']; ?>"><?php echo $item['name']; ?></a></li>
            <?php endforeach; ?>
        </ul>
        
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
            <!-- 清空+恢复功能按钮区 -->
<div class="content-header">
    <h2><?php echo $title; ?></h2>
    <div class="action-buttons">
        <!-- 清空按钮 -->
        <form method="post" action="" onsubmit="return confirm('确定要清空吗？数据会自动备份，可后续恢复');" style="float: right;">
            <input type="hidden" name="level" value="<?php echo $level; ?>">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <button type="submit" name="clear" class="btn btn-danger">一键清空</button>
        </form>

        <!-- 恢复功能 -->
        <form method="post" action="" class="restore-form" onsubmit="return confirm('确定要恢复【<?php echo $selected_backup_date ?: '选中日期'; ?>】的备份吗？');">
            <select name="backup_date" required style="margin-right: 5px;">
                <option value="">选择备份日期</option>
                <?php foreach ($backup_dates as $date): ?>
                    <option value="<?php echo $date; ?>" <?php echo $selected_backup_date == $date ? 'selected' : ''; ?>>
                        <?php echo $date; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="restore" class="btn btn-restore" <?php echo empty($backup_dates) ? 'disabled' : ''; ?>>
                恢复选中备份
            </button>
        </form>
    </div>
</div>

        <!-- 筛选功能表单 -->
        <?php if ($level == 'box'): ?>
        <div class="filter-form" style="margin-bottom: 20px; background-color: #f9f9f9; padding: 15px; border-radius: 4px;">
            <h3>快速筛选</h3>
            <form method="get" action="" style="display: flex; gap: 15px; align-items: flex-end;">
                <div style="flex: 1;">
                    <label for="batch_number">批号：</label>
                    <input type="text" id="batch_number" name="batch_number" value="<?php echo htmlspecialchars($batch_number); ?>" placeholder="请输入批号">
                </div>
                <div style="flex: 1;">
                    <label for="production_date">生产日期：</label>
                    <input type="date" id="production_date" name="production_date" value="<?php echo htmlspecialchars($production_date); ?>">
                </div>
                <div>
                    <input type="hidden" name="level" value="box">
                    <button type="submit" class="btn btn-secondary">筛选</button>
                    <a href="admin_list.php?level=box" class="btn btn-back">重置</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <?php if ($data): ?>
            <table>
                <thead>
                    <tr>
                        <?php if ($level == 'box'): ?>
                            <th>箱子防伪码</th>
                            <th>批号</th>
                            <th>生产日期</th>
                            <th>经销商</th>
                            <th>盒子数量</th>
                            <th>操作</th>
                        <?php elseif ($level == 'carton'): ?>
                            <th>盒子防伪码</th>
                            <th>批号</th>
                            <th>生产日期</th>
                            <th>经销商</th>
                            <th>产品数量</th>
                            <th>操作</th>
                        <?php elseif ($level == 'product'): ?>
                            <th>产品防伪码</th>
                            <th>产品名称</th>
                            <th>生产地区</th>
                            <th>批号</th>
                            <th>生产日期</th>
                            <th>经销商</th>
                            <th>操作</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $item): ?>
                        <tr>
                            <?php if ($level == 'box'): ?>
                                <td><?php echo htmlspecialchars($item['box_code']); ?></td>
                                <td><?php echo htmlspecialchars($item['batch_number']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($item['production_date'])); ?></td>
                                <td><?php echo !empty($item['distributor_name']) ? htmlspecialchars($item['distributor_name']) : '未分配'; ?></td>
                                <!-- 显示实际盒子数量 -->
                                <td><?php echo isset($box_carton_counts[$item['id']]) ? $box_carton_counts[$item['id']] : 0; ?></td>
                                <td class="actions">
                                    <?php 
                                    // 盒子数量大于0时才显示"查看盒子"按钮
                                    $cartonCount = isset($box_carton_counts[$item['id']]) ? $box_carton_counts[$item['id']] : 0;
                                    if ($cartonCount > 0): 
                                    ?>
                                        <a href="admin_list.php?level=carton&id=<?php echo $item['id']; ?>" class="btn">查看盒子</a>
                                    <?php endif; ?>
                                    <button class="btn btn-edit" onclick="openEditModal(<?php echo $item['id']; ?>, 'box', '<?php echo addslashes($item['batch_number']); ?>', '<?php echo date('Y-m-d\TH:i', strtotime($item['production_date'])); ?>')">编辑</button>
                                </td>
                            <?php elseif ($level == 'carton'): ?>
                                <td><?php echo htmlspecialchars($item['carton_code']); ?></td>
                                <td><?php echo htmlspecialchars($item['batch_number']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($item['production_date'])); ?></td>
                                <td><?php echo !empty($item['distributor_name']) ? htmlspecialchars($item['distributor_name']) : '未分配'; ?></td>
                                <!-- 显示实际产品数量 -->
                                <td><?php echo isset($carton_product_counts[$item['id']]) ? $carton_product_counts[$item['id']] : 0; ?></td>
                                <td class="actions">
                                    <?php 
                                    // 产品数量大于0时才显示"查看产品"按钮
                                    $productCount = isset($carton_product_counts[$item['id']]) ? $carton_product_counts[$item['id']] : 0;
                                    if ($productCount > 0): 
                                    ?>
                                        <a href="admin_list.php?level=product&id=<?php echo $item['id']; ?>" class="btn">查看产品</a>
                                    <?php endif; ?>
                                    <button class="btn btn-edit" onclick="openEditModal(<?php echo $item['id']; ?>, 'carton', '<?php echo addslashes($item['batch_number']); ?>', '<?php echo date('Y-m-d\TH:i', strtotime($item['production_date'])); ?>')">编辑</button>
                                </td>
                            <?php elseif ($level == 'product'): ?>
                                <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['region']); ?></td>
                                <td><?php echo htmlspecialchars($item['batch_number']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($item['production_date'])); ?></td>
                                <td><?php echo !empty($item['distributor_name']) ? htmlspecialchars($item['distributor_name']) : '未分配'; ?></td>
                                <td class="actions">
                                    <button class="btn btn-edit" onclick="openEditModal(
                                        <?php echo $item['id']; ?>, 
                                        'product', 
                                        '<?php echo addslashes($item['batch_number']); ?>', 
                                        '<?php echo date('Y-m-d\TH:i', strtotime($item['production_date'])); ?>',
                                        '<?php echo addslashes($item['product_name']); ?>',
                                        '<?php echo addslashes($item['region']); ?>',
                                        '<?php echo addslashes($item['image_url']); ?>'
                                    )">编辑</button>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>没有找到相关数据</p>
        <?php endif; ?>
        
        <?php if ($level != 'box'): ?>
            <a href="admin_list.php?level=<?php echo $level == 'carton' ? 'box' : 'carton'; ?>&id=<?php echo $parent_id; ?>" class="btn btn-back">返回上一级</a>
        <?php endif; ?>
        
        <!-- 分页控件 -->
        <?php if (isset($total_pages) && $total_pages > 1): ?>
            <?php 
                $base_url = 'admin_list.php?level=' . $level;
                if ($id > 0) {
                    $base_url .= '&id=' . $id;
                }
                echo generate_pagination($page, $total_pages, $base_url);
            ?>
        <?php endif; ?>
    </div>
    
    <!-- 编辑模态框 -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>编辑信息</h3>
            <form id="editForm" method="post" action="">
                <input type="hidden" id="editId" name="id">
                <input type="hidden" id="editLevel" name="level" value="<?php echo $level; ?>">
                
                <?php if ($level == 'product' || $level == 'carton' || $level == 'box'): ?>
                    <div class="form-group">
                        <label for="batch_number">批号</label>
                        <input type="text" id="batch_number" name="batch_number" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="production_date">生产日期</label>
                        <input type="datetime-local" id="production_date" name="production_date" required>
                    </div>
                <?php endif; ?>
                
                <?php if ($level == 'product'): ?>
                    <div class="form-group">
                        <label for="product_name">产品名称</label>
                        <input type="text" id="product_name" name="product_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="region">生产地区</label>
                        <input type="text" id="region" name="region" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="image_url">产品图片URL</label>
                        <input type="url" id="image_url" name="image_url">
                    </div>
                <?php endif; ?>
                
                <button type="submit" name="edit" class="btn">保存修改</button>
            </form>
        </div>
    </div>
    
    <script>
        // 获取模态框
        var modal = document.getElementById("editModal");
        var btnClose = document.getElementsByClassName("close")[0];
        
        // 打开模态框
        function openEditModal(id, level, batch, date, name = '', region = '', image = '') {
            document.getElementById("editId").value = id;
            document.getElementById("batch_number").value = batch;
            document.getElementById("production_date").value = date;
            
            if (level == 'product') {
                document.getElementById("product_name").value = name;
                document.getElementById("region").value = region;
                document.getElementById("image_url").value = image;
            }
            
            modal.style.display = "block";
        }
        
        // 关闭模态框
        btnClose.onclick = function() {
            modal.style.display = "none";
        }
        
        // 点击模态框外部关闭
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>
    