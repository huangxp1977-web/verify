<?php
// 开启跨域支持
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

// 引入数据库配置（请替换为实际配置路径）
require '../config/config.php';

$response = [
    'success' => false,
    'code' => 200,
    'message' => '',
    'data' => null,
    'type' => 'certificate'
];

$certNo = isset($_GET['cert_no']) ? trim($_GET['cert_no']) : '';

if (empty($certNo)) {
    $response['code'] = 400;
    $response['message'] = '请提供证书编号（cert_no参数）';
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 检查是否已查询过
    $checkStmt = $pdo->prepare("SELECT is_queried FROM cert_queries WHERE cert_no = :cert_no LIMIT 1");
    $checkStmt->bindParam(':cert_no', $certNo);
    $checkStmt->execute();

    if ($checkStmt->rowCount() > 0) {
        $response['code'] = 403;
        $response['message'] = '该证书查询已失效，仅支持一次有效查询';
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 查询证书信息
    $stmt = $pdo->prepare("
        SELECT cert_name, cert_no, issuer, issue_date, expire_date, image_url, create_time, update_time 
        FROM certificates 
        WHERE cert_no = :cert_no 
        LIMIT 1
    ");
    $stmt->bindParam(':cert_no', $certNo);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $certData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 记录查询状态
        $insertStmt = $pdo->prepare("INSERT INTO cert_queries (cert_no) VALUES (:cert_no)");
        $insertStmt->bindParam(':cert_no', $certNo);
        $insertStmt->execute();

        $response['success'] = true;
        $response['message'] = '查询成功（仅一次有效）';
        $response['data'] = [
            'cert_name' => htmlspecialchars($certData['cert_name']),
            'cert_no' => htmlspecialchars($certData['cert_no']),
            'issuer' => htmlspecialchars($certData['issuer'] ?? ''),
            'issue_date' => htmlspecialchars($certData['issue_date']),
            'expire_date' => htmlspecialchars($certData['expire_date'] ?? ''),
            'image_url' => !empty($certData['image_url']) ? htmlspecialchars($certData['image_url']) : null,
            'create_time' => htmlspecialchars($certData['create_time']),
            'update_time' => htmlspecialchars($certData['update_time'])
        ];
    } else {
        $response['code'] = 404;
        $response['message'] = '证书不存在，请查证';
    }
} catch (PDOException $e) {
    $response['code'] = 500;
    $response['message'] = '服务器查询错误，请稍后重试';
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>