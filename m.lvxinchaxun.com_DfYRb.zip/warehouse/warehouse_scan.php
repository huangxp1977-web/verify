<?php
session_start();
require __DIR__ . '/../config/config.php';

// 检查登录状态
if (!isset($_SESSION['warehouse_staff_logged_in']) || $_SESSION['warehouse_staff_logged_in'] !== true) {
    header('Location: warehouse_login.php');
    exit;
}

// 处理退出
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header('Location: warehouse_login.php');
    exit;
}

$success = '';
$error = '';
$box_info = null;
$distributors = [];

// 获取所有经销商
function getDistributors($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM distributors ORDER BY name ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        return [];
    }
}

// 获取箱子信息
function getBoxInfo($pdo, $code) {
    try {
        $stmt = $pdo->prepare("SELECT b.*, d.name as distributor_name FROM boxes b LEFT JOIN distributors d ON b.distributor_id = d.id WHERE b.box_code = :code");
        $stmt->bindParam(':code', $code);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        return null;
    }
}

// 处理分配经销商
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_distributor'])) {
    $box_code = isset($_POST['box_code']) ? trim($_POST['box_code']) : '';
    $distributor_id = isset($_POST['distributor_id']) ? intval($_POST['distributor_id']) : 0;
    
    if (empty($box_code) || empty($distributor_id)) {
        $error = "请选择经销商并确保扫描了正确的箱子";
    } else {
        try {
            // 开启事务
            $pdo->beginTransaction();
            
            // 获取箱子ID
            $stmt = $pdo->prepare("SELECT id FROM boxes WHERE box_code = :code");
            $stmt->bindParam(':code', $box_code);
            $stmt->execute();
            $box = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($box) {
                $box_id = $box['id'];
                
                // 更新箱子的经销商
                $stmt = $pdo->prepare("UPDATE boxes SET distributor_id = :distributor_id WHERE id = :box_id");
                $stmt->bindParam(':distributor_id', $distributor_id);
                $stmt->bindParam(':box_id', $box_id);
                $stmt->execute();
                
                // 获取该箱子下的所有盒子
                $stmt = $pdo->prepare("SELECT id FROM cartons WHERE box_id = :box_id");
                $stmt->bindParam(':box_id', $box_id);
                $stmt->execute();
                $cartons = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                // 更新盒子的经销商
                if (!empty($cartons)) {
                    $placeholders = implode(',', array_fill(0, count($cartons), '?'));
                    $stmt = $pdo->prepare("UPDATE cartons SET distributor_id = ? WHERE id IN ($placeholders)");
                    $stmt->bindValue(1, $distributor_id, PDO::PARAM_INT);
                    
                    // 绑定盒子ID参数
                    foreach ($cartons as $index => $carton_id) {
                        $stmt->bindValue($index + 2, $carton_id, PDO::PARAM_INT);
                    }
                    
                    $stmt->execute();
                    
                    // 获取这些盒子下的所有产品
                    $stmt = $pdo->prepare("SELECT id FROM products WHERE carton_id IN ($placeholders)");
                    
                    // 再次绑定盒子ID参数
                    foreach ($cartons as $index => $carton_id) {
                        $stmt->bindValue($index + 1, $carton_id, PDO::PARAM_INT);
                    }
                    
                    $stmt->execute();
                    $products = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    // 更新产品的经销商
                    if (!empty($products)) {
                        $product_placeholders = implode(',', array_fill(0, count($products), '?'));
                        $stmt = $pdo->prepare("UPDATE products SET distributor_id = ? WHERE id IN ($product_placeholders)");
                        $stmt->bindValue(1, $distributor_id, PDO::PARAM_INT);
                        
                        // 绑定产品ID参数
                        foreach ($products as $index => $product_id) {
                            $stmt->bindValue($index + 2, $product_id, PDO::PARAM_INT);
                        }
                        
                        $stmt->execute();
                    }
                }
                
                // 提交事务
                $pdo->commit();
                
                // 获取分配后的箱子信息
                $box_info = getBoxInfo($pdo, $box_code);
                
                $success = "经销商分配成功，已将箱子、盒子和产品关联到选定的经销商";
            } else {
                $error = "未找到对应的箱子信息";
                $pdo->rollBack();
            }
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = "分配经销商出错: " . $e->getMessage();
        }
    }
}

// 处理GET参数code查询（支持扫码解析地址）
if (isset($_GET['code']) && !empty(trim($_GET['code']))) {
    $box_code = trim($_GET['code']);
    $box_info = getBoxInfo($pdo, $box_code);
    
    if (!$box_info) {
        $error = "未找到对应的箱子信息";
    }
}

// 处理手动输入/自动提交的箱子代码查询（修复：兼容自动提交）
if (($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['query_box'])) || 
    ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['auto_query']) && $_POST['auto_query'] == '1')) {
    $box_code = isset($_POST['box_code']) ? trim($_POST['box_code']) : '';
    
    if (empty($box_code)) {
        $error = "请输入箱子代码";
    } else {
        $box_info = getBoxInfo($pdo, $box_code);
        
        if (!$box_info) {
            $error = "未找到对应的箱子信息";
        }
    }
}

// 获取经销商列表
try {
    $distributors = getDistributors($pdo);
} catch(PDOException $e) {
    $error = "获取经销商列表出错: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <!-- 移动端基础适配：禁止缩放，确保视图适配屏幕宽度 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>产品出库扫码 - 产品溯源系统</title>
    <style>
        /* 全局样式重置与基础设置 */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-tap-highlight-color: transparent; /* 清除移动端点击高亮 */
        }
        
        body {
            font-family: "Microsoft YaHei", Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 10px;
            background-color: #f4f4f4;
            background-image: url('images/bg-pattern.png');
            background-repeat: repeat;
            color: #333;
            min-height: 100vh;
        }
        
        /* 主容器样式 */
        .container {
            width: 100%;
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #c09f5e;
        }
        
        h1 {
            color: #8c6f3f;
            font-size: 28px;
            margin: 0;
            text-align: center;
            font-weight: bold;
        }
        
        .header h1 {
            text-align: left;
        }
        
        h2 {
            color: #8c6f3f;
            font-size: 24px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        /* 按钮基础样式 */
        .btn {
            padding: 10px 20px;
            background: #8c6f3f;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background: #6d5732;
        }
        
        .btn-secondary {
            background: #3498db;
        }
        
        .btn-secondary:hover {
            background: #2980b9;
        }
        
        .btn-danger, .btn-logout {
            background: #e74c3c;
        }
        
        .btn-danger:hover, .btn-logout:hover {
            background: #c0392b;
        }
        
        /* 区块样式 */
        .section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #eee;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        
        /* 表单基础样式 */
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
            outline: none; /* 清除默认聚焦边框 */
        }
        
        /* 输入框聚焦效果优化 */
        input:focus, select:focus {
            border-color: #8c6f3f;
            box-shadow: 0 0 0 2px rgba(140, 111, 63, 0.2);
        }
        
        /* 提示信息样式 */
        .success {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .error {
            background-color: #f2dede;
            color: #a94442;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        /* 扫码区域样式 */
        .qr-scanner {
            position: relative;
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }
        
        #qr-video {
            width: 100%;
            border-radius: 8px;
            border: 2px solid #8c6f3f;
        }
        
        #qr-canvas {
            display: none;
        }
        
        .scan-area {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 250px;
            height: 250px;
            border: 2px solid #8c6f3f;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.2);
            pointer-events: none;
        }
        
        .scan-area::before,
        .scan-area::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            border-color: #8c6f3f;
            border-style: solid;
        }
        
        .scan-area::before {
            top: -4px;
            left: -4px;
            border-width: 4px 0 0 4px;
        }
        
        .scan-area::after {
            top: -4px;
            right: -4px;
            border-width: 4px 4px 0 0;
        }
        
        .scan-area span::before {
            bottom: -4px;
            left: -4px;
            border-width: 0 0 4px 4px;
        }
        
        .scan-area span::after {
            bottom: -4px;
            right: -4px;
            border-width: 0 4px 4px 0;
        }
        
        /* 箱子信息区域样式 */
        .box-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-top: 20px;
        }
        
        .box-info h3 {
            color: #8c6f3f;
            margin-top: 0;
        }
        
        .box-info p {
            margin: 10px 0;
        }
        
        .box-info .label {
            font-weight: bold;
            color: #555;
        }
        
        .distributor-assigned {
            color: #27ae60;
            font-weight: bold;
        }
        
        .distributor-unassigned {
            color: #e74c3c;
        }
        
        .actions {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .staff-info {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #eee;
        }
        
        .staff-info .welcome {
            font-size: 18px;
            color: #8c6f3f;
            margin: 0;
        }

        /* -------------- 退出登录弹窗样式 -------------- */
        .logout-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .logout-modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 400px;
            text-align: center;
        }
        
        .logout-modal h3 {
            color: #333;
            margin-bottom: 20px;
            font-size: 22px;
        }
        
        .logout-modal-buttons {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .logout-modal-buttons .btn {
            flex: 1;
        }
        
        .logout-trigger {
            background: #8c6f3f;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            font-size: 20px;
            border: none;
        }
        
        /* -------------- 扫码成功提示弹窗 -------------- */
        .scan-success-modal {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            display: none;
            z-index: 900;
        }
        
        .scan-success-modal p {
            margin: 0 0 15px 0;
            font-size: 16px;
            text-align: center;
        }
        
        .countdown {
            font-weight: bold;
            color: #8c6f3f;
        }
        
        .scan-success-buttons {
            display: flex;
            gap: 10px;
        }
        
        .scan-success-buttons .btn {
            flex: 1;
        }

        /* -------------- 移动端核心优化（768px以下） -------------- */
        @media (max-width: 768px) {
            /* 主容器适配：移除阴影，贴合屏幕 */
            .container {
                padding: 10px 15px;
                margin: 0;
                box-shadow: none;
                border-radius: 0;
            }
            
            /* 标题适配：放大字体，居中显示 */
            h1 {
                font-size: 26px !important;
                text-align: center !important;
                margin-bottom: 15px !important;
                flex: 1;
            }
            
            h2 {
                font-size: 22px !important;
                margin-bottom: 15px !important;
                padding-bottom: 8px !important;
            }
            
            /* 扫码区域优化：适配手机屏幕，保证足够高度 */
            .qr-scanner {
                max-width: 100% !important;
                padding: 0 5px;
            }
            
            #qr-video {
                width: 100% !important;
                height: auto !important;
                min-height: 300px !important; /* 确保扫码区域不过小 */
            }
            
            .scan-area {
                width: 220px !important;
                height: 220px !important;
            }
            
            /* 按钮优化：全屏宽度，放大点击区域，增加内边距 */
            .btn {
                width: 100% !important;
                padding: 14px 0 !important;
                font-size: 18px !important;
                margin-bottom: 12px !important;
                border-radius: 8px !important;
            }
            
            /* 核心：输入框优化 */
            .form-group input[type="text"],
            .form-group select {
                font-size: 18px !important; /* 放大输入字体，便于查看 */
                padding: 16px 15px !important; /* 增加内边距，增大输入框尺寸 */
                height: 58px !important; /* 固定高度，确保显示一致 */
                border-radius: 8px !important;
                border: 1px solid #ccc !important;
                letter-spacing: 0.5px; /* 增加字间距，提升可读性 */
            }
            
            /* 手动输入表单布局：垂直排列更适合手机 */
            .form-group div {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            
            /* 区块间距优化 */
            .section {
                margin-bottom: 20px;
                padding: 15px;
            }
            
            /* 信息提示样式优化 */
            .success, .error {
                padding: 12px 15px;
                font-size: 16px;
            }
            
            /* 员工信息区域优化 */
            .staff-info {
                padding: 12px;
                margin-bottom: 15px;
            }
            
            .staff-info .welcome {
                font-size: 17px;
            }
            
            /* 箱子信息区域优化 */
            .box-info {
                padding: 15px;
                margin-top: 15px;
            }
            
            .box-info p {
                font-size: 16px;
                margin: 8px 0;
            }
            
            /* 弹窗在移动端的优化 */
            .logout-modal-content {
                padding: 25px 20px;
            }
            
            .scan-success-modal {
                padding: 15px;
                bottom: 20px;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
</head>
<body>
    <!-- 主内容区域 -->
    <div class="container">
            <div class="header">
                <h1>产品出库扫码</h1>
                <!-- 退出登录按钮改为图标按钮 -->
                <button class="logout-trigger" id="logoutTrigger">
                    <i>ⓧ</i>
                </button>
            </div>
        
        <div class="staff-info">
            <p class="welcome">欢迎，<?php echo htmlspecialchars($_SESSION['warehouse_staff_name']); ?>！</p>
        </div>
        
        <?php if (!empty($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="section">
            <h2>扫描外箱二维码</h2>
            
            <div class="qr-scanner">
                <video id="qr-video"></video>
                <div class="scan-area">
                    <span></span>
                </div>
                <canvas id="qr-canvas"></canvas>
            </div>
            
<div class="form-group" style="margin-top: 20px;">
    <form method="post" action="" id="queryForm">
        <!-- 新增：用于标记是否是自动提交（避免重复处理） -->
        <input type="hidden" name="auto_query" value="0">
        <label for="box_code">或手动输入箱子代码：</label>
        <div style="display: flex; gap: 10px;">
            <input type="text" id="box_code" name="box_code" placeholder="请输入箱子代码" 
                   value="<?php echo $box_info ? htmlspecialchars($box_info['box_code']) : ''; ?>">
            <button type="submit" name="query_box" class="btn btn-secondary" style="flex-shrink: 0;">查询</button>
        </div>
    </form>
</div>
        
        <?php if ($box_info): ?>
            <div class="section">
                <h2>箱子信息</h2>
                <div class="box-info">
                    <h3>产品外箱信息</h3>
                    <p><span class="label">箱子代码：</span><?php echo htmlspecialchars($box_info['box_code']); ?></p>
                    <p><span class="label">批号：</span><?php echo htmlspecialchars($box_info['batch_number']); ?></p>
                    <p><span class="label">生产日期：</span><?php echo htmlspecialchars($box_info['production_date']); ?></p>
                    <p><span class="label">当前经销商：</span>
                        <?php if (!empty($box_info['distributor_name'])): ?>
                            <span class="distributor-assigned">已分配：<?php echo htmlspecialchars($box_info['distributor_name']); ?></span>
                        <?php else: ?>
                            <span class="distributor-unassigned">未分配</span>
                        <?php endif; ?>
                    </p>
                    <p><span class="label">创建时间：</span><?php echo $box_info['created_at']; ?></p>
                    
                    <form method="post" action="">
                        <input type="hidden" name="box_code" value="<?php echo htmlspecialchars($box_info['box_code']); ?>">
                        <div class="form-group">
                            <label for="distributor_id">选择经销商：</label>
                            <select id="distributor_id" name="distributor_id" required>
                                <option value="">请选择经销商</option>
                                <?php if (count($distributors) > 0): ?>
                                    <?php foreach ($distributors as $distributor): ?>
                                        <option value="<?php echo $distributor['id']; ?>"<?php echo ($box_info['distributor_id'] == $distributor['id']) ? ' selected' : ''; ?>>
                                            <?php echo htmlspecialchars($distributor['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <button type="submit" name="assign_distributor" class="btn">分配经销商</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- 退出登录弹窗 -->
    <div class="logout-modal" id="logoutModal">
        <div class="logout-modal-content">
            <h3>确认退出登录？</h3>
            <p>您确定要退出当前登录状态吗？</p>
            <div class="logout-modal-buttons">
                <button class="btn btn-secondary" id="cancelLogout">取消</button>
                <a href="?action=logout" class="btn btn-danger">确认退出</a>
            </div>
        </div>
    </div>
    
    <!-- 扫码成功提示弹窗 -->
    <div class="scan-success-modal" id="scanSuccessModal">
        <p>扫码成功！将在 <span class="countdown" id="countdown">2</span> 秒后自动查询</p>
        <div class="scan-success-buttons">
            <button class="btn btn-secondary" id="cancelAutoQuery">取消</button>
            <button class="btn" id="manualQueryNow">立即查询</button>
        </div>
    </div>
    
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // 获取DOM元素
    const logoutTrigger = document.getElementById('logoutTrigger');
    const logoutModal = document.getElementById('logoutModal');
    const cancelLogout = document.getElementById('cancelLogout');
    const scanSuccessModal = document.getElementById('scanSuccessModal');
    const countdownElement = document.getElementById('countdown');
    const cancelAutoQuery = document.getElementById('cancelAutoQuery');
    const manualQueryNow = document.getElementById('manualQueryNow');
    const queryForm = document.getElementById('queryForm');
    const boxCodeInput = document.getElementById('box_code');
    const autoQueryInput = document.querySelector('input[name="auto_query"]');
    
    // 状态变量
    let countdownInterval = null;
    let scanning = false;
    let lastScannedCode = '';
    let isProcessing = false; // 防止重复处理的锁
    
    // 退出登录弹窗控制
    logoutTrigger.addEventListener('click', () => {
        logoutModal.style.display = 'flex';
    });
    
    cancelLogout.addEventListener('click', () => {
        logoutModal.style.display = 'none';
    });
    
    logoutModal.addEventListener('click', (e) => {
        if (e.target === logoutModal) {
            logoutModal.style.display = 'none';
        }
    });
    
    // 扫码成功弹窗控制
    cancelAutoQuery.addEventListener('click', () => {
        scanSuccessModal.style.display = 'none';
        clearInterval(countdownInterval);
        isProcessing = false; // 释放锁
    });
    
    manualQueryNow.addEventListener('click', () => {
        if (!queryForm) {
            alert('查询表单不存在，请刷新页面重试');
            return;
        }
        
        scanSuccessModal.style.display = 'none';
        clearInterval(countdownInterval);
        
        // 标记为自动查询
        if (autoQueryInput) {
            autoQueryInput.value = "1";
        }
        
        queryForm.submit();
        isProcessing = false; // 释放锁
    });
    
    // 二维码扫描功能
    const video = document.getElementById('qr-video');
    const canvas = document.getElementById('qr-canvas');
    const canvasContext = canvas.getContext('2d');
    
    // 请求摄像头权限并启动扫描
    async function startScanner() {
        try {
            // 移动端优化的摄像头设置
            const constraints = {
                video: {
                    facingMode: 'environment',
                    width: { ideal: 1280, max: 1920 },
                    height: { ideal: 720, max: 1080 },
                    focusMode: 'continuous'
                }
            };
            
            // 检查浏览器支持
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('您的浏览器不支持摄像头访问');
            }
            
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            
            video.srcObject = stream;
            video.setAttribute('playsinline', true); // iOS Safari 支持
            await video.play();
            scanning = true;
            
            // 设置canvas尺寸与视频一致
            const setCanvasDimensions = () => {
                if (video.videoWidth && video.videoHeight) {
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                }
            };
            
            video.addEventListener('loadedmetadata', setCanvasDimensions);
            window.addEventListener('resize', setCanvasDimensions);
            
            // 开始扫描循环
            scan();
            
        } catch (error) {
            console.error('启动摄像头失败:', error);
            alert(`无法访问摄像头: ${error.message}\n请确保已授予摄像头权限并尝试刷新页面`);
        }
    }
    
    // 扫描处理函数
    function scan() {
        if (!scanning || isProcessing) return;
        
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvasContext.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvasContext.getImageData(0, 0, canvas.width, canvas.height);
            
            // 扫描二维码
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
                inversionAttempts: "attemptBoth",
                greyScaleWeights: { red: 0.2989, green: 0.5870, blue: 0.1140 }
            });
            
            if (code && code.data && code.data !== lastScannedCode) {
                isProcessing = true; // 锁定处理状态
                lastScannedCode = code.data;
                
                // 清理扫描结果
                let cleanCode = code.data.trim();
                
                // 提取URL中的code参数
                if (cleanCode.includes('?code=')) {
                    const codeMatch = cleanCode.match(/\?code=(.+)/);
                    if (codeMatch && codeMatch[1]) {
                        cleanCode = codeMatch[1];
                    }
                }
                
                // 填充到输入框
                if (boxCodeInput) {
                    boxCodeInput.value = cleanCode;
                    boxCodeInput.dispatchEvent(new Event('input', { bubbles: true }));
                    boxCodeInput.dispatchEvent(new Event('change', { bubbles: true }));
                }
                
                // 显示成功弹窗并倒计时
                showScanSuccessModal();
                
                console.log('扫描到的内容:', code.data);
                console.log('处理后的代码:', cleanCode);
            }
        }
        
        // 继续扫描循环
        requestAnimationFrame(scan);
    }
    
    // 显示扫码成功弹窗并处理自动提交
    function showScanSuccessModal() {
        let seconds = 2;
        countdownElement.textContent = seconds;
        scanSuccessModal.style.display = 'block';
        
        // 清除之前的计时器
        if (countdownInterval) {
            clearInterval(countdownInterval);
        }
        
        // 开始倒计时
        countdownInterval = setInterval(() => {
            seconds--;
            countdownElement.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(countdownInterval);
                scanSuccessModal.style.display = 'none';
                
                // 检查表单是否存在
                if (!queryForm) {
                    console.error('查询表单不存在');
                    alert('自动查询失败，请手动输入并查询');
                    isProcessing = false;
                    return;
                }
                
                // 标记为自动查询
                if (autoQueryInput) {
                    autoQueryInput.value = "1";
                }
                
                // 提交表单
                try {
                    queryForm.submit();
                } catch (submitError) {
                    console.error('表单提交失败:', submitError);
                    alert('提交失败，请手动点击查询按钮');
                    isProcessing = false;
                }
            }
        }, 1000);
    }
    
    // 移动端输入框优化
    if (boxCodeInput) {
        boxCodeInput.addEventListener('focus', () => {
            if (window.innerWidth <= 768) {
                setTimeout(() => {
                    window.scrollTo({
                        top: boxCodeInput.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }, 300);
            }
        });
    }
    
    // 初始化扫描
    startScanner();
});

    </script>
</body>
</html>